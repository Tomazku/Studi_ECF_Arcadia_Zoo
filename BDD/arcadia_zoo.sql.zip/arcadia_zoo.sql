-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : sam. 18 mai 2024 à 13:07
-- Version du serveur : 8.2.0
-- Version de PHP : 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `arcadia_zoo`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int NOT NULL AUTO_INCREMENT,
  `mail` varchar(50) NOT NULL,
  `motDePasse` varchar(50) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id_admin`, `mail`, `motDePasse`) VALUES
(1, 'admin@arcadia.zoo', 'Arcadia_zoo');

-- --------------------------------------------------------

--
-- Structure de la table `animal`
--

DROP TABLE IF EXISTS `animal`;
CREATE TABLE IF NOT EXISTS `animal` (
  `animal_id` int NOT NULL AUTO_INCREMENT,
  `image` varchar(255) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `prenom` varchar(50) DEFAULT NULL,
  `etat` varchar(50) DEFAULT NULL,
  `rapport_veterinaire_id` int DEFAULT NULL,
  `race_id` int DEFAULT NULL,
  `habitat_id` int DEFAULT NULL,
  PRIMARY KEY (`animal_id`),
  KEY `rapport_veterinaire_id` (`rapport_veterinaire_id`),
  KEY `fk_race_id` (`race_id`),
  KEY `fk_habitat_id` (`habitat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `animal`
--

INSERT INTO `animal` (`animal_id`, `image`, `prenom`, `etat`, `rapport_veterinaire_id`, `race_id`, `habitat_id`) VALUES
(1, '', NULL, 'Félin', NULL, NULL, NULL),
(2, '', NULL, 'Batracien', NULL, NULL, NULL),
(3, '', NULL, 'Reptile', NULL, NULL, NULL),
(4, '', NULL, 'Oiseau', NULL, NULL, NULL),
(5, '', NULL, 'Mammifère', NULL, NULL, NULL),
(22, 'uploads/Zara.jpg', 'Fanfan', 'Sain', NULL, 1, 2),
(21, 'uploads/George.jpg', 'George', 'Convalescent', NULL, 5, 1),
(20, 'uploads/Ellie_Alligator.jpg', 'Ellie - Aligator ', 'En traitement', NULL, 3, 3),
(19, 'uploads/Billy-jaguar.jpg', 'Billy - Jaguar', 'À surveiller', NULL, 1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `avis`
--

DROP TABLE IF EXISTS `avis`;
CREATE TABLE IF NOT EXISTS `avis` (
  `avis_id` int NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(50) NOT NULL,
  `commentaire` varchar(500) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `isVisible` tinyint(1) NOT NULL,
  PRIMARY KEY (`avis_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `avis`
--

INSERT INTO `avis` (`avis_id`, `pseudo`, `commentaire`, `isVisible`) VALUES
(1, 'Thomas', 'Très bien', 1),
(2, 'Ulysse', 'Trop bien, que des animaux trop cool !', 1),
(5, 'Luns', 'Les animaux sont trop bien mais ça manque cruellement de chien', 1),
(7, 'Test', 'Test', 0);

-- --------------------------------------------------------

--
-- Structure de la table `employes`
--

DROP TABLE IF EXISTS `employes`;
CREATE TABLE IF NOT EXISTS `employes` (
  `employe_id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `motDePasse` varchar(50) NOT NULL,
  PRIMARY KEY (`employe_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `employes`
--

INSERT INTO `employes` (`employe_id`, `nom`, `motDePasse`) VALUES
(1, 'employe@arcadia.zoo', 'Arcadia_zoo');

-- --------------------------------------------------------

--
-- Structure de la table `habitat`
--

DROP TABLE IF EXISTS `habitat`;
CREATE TABLE IF NOT EXISTS `habitat` (
  `habitat_id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `description` varchar(1000) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `image` varchar(250) NOT NULL,
  `commentaire_habitat` text NOT NULL,
  PRIMARY KEY (`habitat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `habitat`
--

INSERT INTO `habitat` (`habitat_id`, `nom`, `description`, `image`, `commentaire_habitat`) VALUES
(1, 'Jungle', 'La jungle du Zoo Arcadia est un havre de biodiversité, où une canopée dense domine et crée un monde d\'ombre et de mystère. Ici, vous pouvez observer des perroquets aux couleurs vives et des singes agiles évoluant librement dans les arbres, tandis que le sol est le territoire des jaguars silencieux et des paresseux nonchalants. La richesse des plantes exotiques ajoute à la sensation d\'être dans une forêt tropicale dense, où chaque pas révèle une nouvelle merveille naturelle. Les cris des animaux résonnent, créant une symphonie naturelle qui enchante tous ceux qui la traversent. Ce cadre luxuriant est aussi un espace d’éducation où les visiteurs apprennent l’importance de la conservation des habitats tropicaux.\r\n\r\n', 'uploads/Jungle.webp', 'Ajout d\'un commentaire concernant l\'habitat'),
(2, 'Savane', 'Explorez l\'immensité ouverte de la savane du Zoo Arcadia, où les horizons lointains sont ponctués de silhouettes d\'acacias et animés par les déplacements des grands troupeaux. Dans cet habitat, vous pouvez admirer des girafes gracieuses broutant parmi les hautes branches, des zèbres rayés galopant à travers les plaines et des lions se prélassant sous le soleil africain. La savane est conçue pour imiter le grand air ouvert, offrant aux animaux beaucoup d\'espace pour se comporter naturellement. Des safaris guidés permettent aux visiteurs de découvrir la complexité écologique de cet écosystème et l\'importance cruciale de sa préservation.', 'uploads/Savane.webp', '2'),
(3, 'Marais', 'Les marais du Zoo Arcadia offrent un aperçu de cet écosystème souvent méconnu, caractérisé par une eau riche en nutriments et une diversité d\'espèces adaptées à la vie aquatique. Cet habitat humide est le foyer de nombreuses espèces de reptiles, d\'amphibiens et d\'oiseaux aquatiques. Les visiteurs peuvent observer des crocodiles immobiles au bord de l\'eau, des tortues naviguant tranquillement et des libellules virevoltant au-dessus des eaux calmes. Des passerelles en bois permettent de traverser les zones humides, offrant une expérience immersive sans perturber la quiétude de l\'écosystème. C\'est un lieu d\'apprentissage sur l\'importance des zones humides pour la biodiversité et la régulation hydrologique.', 'uploads/Marais.jpg', '3');

-- --------------------------------------------------------

--
-- Structure de la table `horaires_ouverture`
--

DROP TABLE IF EXISTS `horaires_ouverture`;
CREATE TABLE IF NOT EXISTS `horaires_ouverture` (
  `horaires_id` int NOT NULL AUTO_INCREMENT,
  `jour` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `heure_ouverture` time DEFAULT NULL,
  `heure_fermeture` time DEFAULT NULL,
  `ferme` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`horaires_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `horaires_ouverture`
--

INSERT INTO `horaires_ouverture` (`horaires_id`, `jour`, `heure_ouverture`, `heure_fermeture`, `ferme`) VALUES
(1, 'Lundi', '12:00:00', '18:00:00', 1),
(2, 'Mardi', '10:00:00', '19:00:00', 0),
(3, 'Mercredi', '10:00:00', '19:00:00', 0),
(4, 'Jeudi', '10:00:00', '19:00:00', 0),
(5, 'Vendredi', '10:00:00', '19:00:00', 0),
(6, 'Samedi', '09:00:00', '19:00:00', 0),
(7, 'Dimanche', '10:00:00', '17:00:00', 1);

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

DROP TABLE IF EXISTS `image`;
CREATE TABLE IF NOT EXISTS `image` (
  `image_id` int NOT NULL AUTO_INCREMENT,
  `image_data` blob NOT NULL,
  `habitat_id` int DEFAULT NULL,
  PRIMARY KEY (`image_id`),
  KEY `fk_habitat_id` (`habitat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id_message` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `messages` text NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_message`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id_message`, `nom`, `prenom`, `email`, `messages`, `date_time`) VALUES
(30, 'Laprie', 'Thomas', 'tlaprie@gmail.com', 'Top of the top', '2024-05-08 15:37:41'),
(29, 'Laprie', 'Thomas', 'tlaprie@gmail.com', 'Top of the top', '2024-05-08 15:37:22'),
(28, 'Laprie', 'Thomas', 'tlaprie@gmail.com', 'Top of the top', '2024-05-08 15:37:22'),
(27, 'Laprie', 'Thomas', 'tlaprie@gmail.com', 'Top of the top', '2024-05-08 15:37:21'),
(26, 'Laprie', 'Thomas', 'tlaprie@gmail.com', 'Top of the top', '2024-05-08 15:37:20'),
(25, 'Laprie', 'Thomas', 'tlaprie@gmail.com', 'Top of the top', '2024-05-08 15:37:18'),
(24, 'Laprie', 'Thomas', 'tlaprie@gmail.com', 'Est-ce qu&#39;il est possible d&#39;acheter une girafe? ', '2024-05-08 15:32:53'),
(23, 'tet', 'tet', 'tett@ata.gr', 'gzgz', '2024-05-07 19:20:29'),
(22, 'tet', 'tet', 'tett@ata.gr', 'gzgz', '2024-05-07 19:20:14'),
(21, 'Laprie', 'Thomas', 'thomas@laprie.fr', 'Ceci est un message pour tester la messagerie', '2024-05-07 19:15:39'),
(31, 'zgzze', 'gzagz', 'tlaqfa@faf.com', 'sgzgzzs', '2024-05-08 15:42:45');

-- --------------------------------------------------------

--
-- Structure de la table `race`
--

DROP TABLE IF EXISTS `race`;
CREATE TABLE IF NOT EXISTS `race` (
  `race_id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(50) NOT NULL,
  PRIMARY KEY (`race_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `race`
--

INSERT INTO `race` (`race_id`, `label`) VALUES
(1, 'Félin'),
(2, 'Batracien'),
(3, 'Reptile'),
(4, 'Oiseau'),
(5, 'Mammifère');

-- --------------------------------------------------------

--
-- Structure de la table `rapport_veterinaire`
--

DROP TABLE IF EXISTS `rapport_veterinaire`;
CREATE TABLE IF NOT EXISTS `rapport_veterinaire` (
  `rapport_veterinaire_id` int NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `detail` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `animal_id` int DEFAULT NULL,
  PRIMARY KEY (`rapport_veterinaire_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `rapport_veterinaire`
--

INSERT INTO `rapport_veterinaire` (`rapport_veterinaire_id`, `date`, `detail`, `animal_id`) VALUES
(1, '2024-05-15', 'L\'animal est en bonne santé et il s\'adapte bien à ', 6),
(2, '2024-05-15', 'L\'animal est en bonne santé et il s\'adapte bien à son environnement ', 6);

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `label` varchar(50) NOT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Structure de la table `service`
--

DROP TABLE IF EXISTS `service`;
CREATE TABLE IF NOT EXISTS `service` (
  `service_id` int NOT NULL AUTO_INCREMENT,
  `categorie` enum('Restaurants','Activités','Animations','') CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `image_service` varchar(255) NOT NULL,
  `nom` varchar(250) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `service`
--

INSERT INTO `service` (`service_id`, `categorie`, `image_service`, `nom`, `description`) VALUES
(11, 'Restaurants', 'Terrasse_familiale.jpg', 'Service de Restauration Familiale : La Terrasse Familiale	', 'La Terrasse Familiale au Zoo Arcadia offre une atmosphère détendue et accueillante, idéale pour les familles visitant le zoo. Située à proximité des principales attractions, ce restaurant est un excellent choix pour reprendre des forces tout en profitant de la vue sur les enclos des animaux. Menu : Le menu de La Terrasse Familiale est conçu pour plaire à tous les âges, avec une variété d\'options allant des snacks rapides aux plats plus substantiels. Les menus enfants sont disponibles avec des surprises pour les plus jeunes. Ambiance : Colorée et animée, La Terrasse Familiale est décorée de motifs inspirés de la faune et de la flore, créant un environnement fun et engageant pour les enfants. Les tables sont espacées pour offrir de l\'espace aux poussettes et aux groupes familiaux. Services spéciaux : Le restaurant propose des ateliers culinaires pour enfants pendant les week-ends et les vacances scolaires, offrant une expérience éducative et divertissante qui permet aux enfants d\'apprendre tout en s\'amusant. Cette option de restauration à Zoo Arcadia permet aux familles de profiter d\'un moment de détente et de plaisir, tout en offrant des mets adaptés à tous les palais.	\r\n'),
(12, 'Activités', 'visite_guidee.jpg', 'Visite Guidée Découverte', 'Rejoignez nos guides experts pour une visite guidée captivante à travers le Zoo Arcadia. Découvrez les secrets de nos résidents les plus aimés, apprenez sur les habitats naturels et les efforts de conservation qui aident à protéger les espèces en voie de disparition. Parfait pour les familles et les passionnés de nature, cette visite enrichissante est offerte gratuitement tous les jours à 10h et 15h. Durée approximative : 1 heure. Point de rencontre à l\'entrée principale. Inscription préalable recommandée.'),
(10, 'Restaurants', 'Le_Pavillon_etoile.jpg', 'Service de Restauration Haut de Gamme : Le Pavillon Étoilé', 'Au Zoo Arcadia, le Pavillon Étoilé propose une expérience culinaire haut de gamme dans un cadre élégant et raffiné. Idéal pour les visiteurs qui cherchent à ajouter une touche de luxe à leur journée, ce restaurant offre une vue imprenable sur les jardins du zoo et certaines de ses expositions les plus exotiques.Menu : Le Pavillon Étoilé se distingue par un menu gastronomique conçu par des chefs étoilés, mettant en avant des ingrédients locaux et saisonniers. La carte des vins comprend une sélection impressionnante de vins fins et de champagnes pour compléter parfaitement votre repas.Ambiance : Avec son intérieur élégamment décoré et une musique d\'ambiance douce, le Pavillon Étoilé est parfait pour les occasions spéciales, les dîners romantiques ou les réunions d\'affaires discrètes.Services spéciaux : Le restaurant offre des options de réservation privée et de personnalisation de menu pour les événements spéciaux, ainsi que des guides sommeliers pour une expérience de dégustation de vin immersive.		'),
(13, 'Activités', 'visite_petit_train.jpg', 'Tour en Petit Train', 'Embarquez pour un tour enchanté du Zoo Arcadia à bord de notre petit train. Ce circuit panoramique est une manière fantastique pour les visiteurs de tous âges de découvrir le zoo sans se fatiguer. Le trajet couvre tous les principaux habitats et attractions, avec des commentaires divertissants qui révèlent anecdotes et faits intéressants sur nos animaux et installations. Les départs ont lieu toutes les heures de 9h à 17h depuis la station centrale près de l\'entrée. Gratuit pour tous nos visiteurs.'),
(14, 'Animations', 'spectacles_enfant.jpg', 'Mini-spectacles pour enfants ', 'Venez assister à nos mini-spectacles spécialement conçus pour divertir les plus jeunes ! Nos animateurs talentueux offrent des performances ludiques et interactives qui captiveront toute la famille. Plongez dans un monde de magie, de musique et de rires avec nos spectacles quotidiens.'),
(15, 'Animations', 'atelier_enfant.jpg', 'Ateliers éducatifs', 'Explorez le monde fascinant de la nature à travers nos ateliers éducatifs interactifs. Que vous souhaitiez en apprendre davantage sur les espèces animales, la conservation de l\'environnement ou les sciences naturelles, nos animateurs expérimentés sont là pour vous guider. Rejoignez-nous pour des activités amusantes et enrichissantes qui éveilleront votre curiosité et nourriront votre amour pour la nature.');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

DROP TABLE IF EXISTS `utilisateurs`;
CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `utilisateur_id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `motDePasse` varchar(50) NOT NULL,
  `role` enum('admin','employe','veterinaire','') NOT NULL,
  PRIMARY KEY (`utilisateur_id`),
  UNIQUE KEY `email utilisateur` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb3;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`utilisateur_id`, `email`, `motDePasse`, `role`) VALUES
(1, 'admin@arcadia.zoo', 'Arcadia_zoo', 'admin'),
(5, 'employe@arcadia.zoo', '$2y$10$JcAPO9yHrZcd.vCgHRCOeuw0VAZHw9.yjaxomn1IkoO', 'employe'),
(4, 'veterinaire@arcadia.zoo', 'Arcadia_zoo', 'veterinaire'),
(7, 'employe2@arcadia.zoo', '$2y$10$kvk/ER2uwiXDPNOPxrWrKOShIwWm1d7FgVzyeuIfv7K', 'employe');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
